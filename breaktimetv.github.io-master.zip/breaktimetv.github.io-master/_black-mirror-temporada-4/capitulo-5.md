---
layout: episodio
title: "Black Mirror 4x05"
url_serie_padre: 'black-mirror-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2016'
prev: 'capitulo-4'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductor: fembed
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZwNmVYamNUVTNMWEdqSXVHMktuYnZjK25hR2U2eHRpMzNZZG5mcEs2cXQ2U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402296/black-4-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











