---
layout: episodio
title: "Black Mirror 4x02"
url_serie_padre: 'black-mirror-temporada-4'
category: 'series'
anio: '2016'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZxWHRmcGNmYjM3ZXFvM21LeDZySnI3aG9oNG00eUtTd3RtU3NtTGF2MzdHU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402296/black-4-banner-min.jpg'
tags:
- Ciencia-Ficcion
---










