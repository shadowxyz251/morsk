---
layout: episodio
title: "Black Mirror 4x01"
url_serie_padre: 'black-mirror-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2016'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z1Sm1jaWRUUjNhKzBrb1Y4cHNES3ZybVNlWWF5MnJhNWxwNmthcmlhNkwyU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402296/black-4-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











