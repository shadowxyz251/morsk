---
layout: episodio
title: "Dark 2x01"
url_serie_padre: 'dark-temporada-2'
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1561171881/dark2banner-min_hmfg51.jpg'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YzSmRuZ0szS3RObTFhWGwzajdpN3lOV1dkcWliek9hM21YMnFpdEN0NkxtU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











