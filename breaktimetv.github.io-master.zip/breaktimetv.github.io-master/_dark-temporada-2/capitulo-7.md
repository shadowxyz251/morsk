---
layout: episodio
title: "Dark 2x07"
url_serie_padre: 'dark-temporada-2'
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1561171881/dark2banner-min_hmfg51.jpg'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-6'
proximo: 'capitulo-8'
anio: '2019'
sandbox: allow-same-origin allow-forms
calidad: 'Full HD'
idioma: 'Subtitulado'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZyNlNEcTdmUHFOckNwS0dZeWE2bXROU0VsbmVrdU1lVmxZYWduSlM0dzZlU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











