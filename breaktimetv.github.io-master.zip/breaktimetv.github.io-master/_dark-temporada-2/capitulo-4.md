---
layout: episodio
title: "Dark 2x04"
url_serie_padre: 'dark-temporada-2'
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1561171881/dark2banner-min_hmfg51.jpg'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2019'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
calidad: 'Full HD'
idioma: 'Subtitulado'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZsWVI1Zk5iUG9KeXRhNFNmemEvZ3BwT0puWVdZMStQY3U1bDducWZTeThPU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











