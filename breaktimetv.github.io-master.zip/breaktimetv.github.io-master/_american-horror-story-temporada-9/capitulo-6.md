---
layout: episodio
title: "American Horror Story 9x06"
url_serie_padre: 'american-horror-story-temporada-9'
category: 'series'
anio: '2019'
capitulo: 'yes'
prev: 'capitulo-5'
proximo: 'capitulo-7'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/olpremium/gd.php?file=ek5lbm9xYWNrS0xNejZabVlkSFIyTkxQb3BPWDB0UFkwY3lvbjJIRjBPQ1QwNStUck1mVG9kVExvM0djeHA3VnFybXRscUdvMWRXNHRZbU1lYXVUeDg2cGpKVmp4cXpBejYxcGsyVE4xOWE2clhlSm5hU254TStjb0plZHE1VFdsSmlyaGFER3NzWFAwcXFWWTVPdTE4L1hnNGhtdktQVXo5SmppNTdHc01lNzA2V1hvYVN2ekpTcGdZZXR5clRHdUtsNWdHTzBxTldzem1pR1pMQ1N5TkxHYklLRWlNbmYxOG1ZYjZ6SDFBPT0"]
tags:
- Terror
---










