---
layout: episodio
title: "American Horror Story 9x04"
url_serie_padre: 'american-horror-story-temporada-9'
category: 'series'
anio: '2017'
capitulo: 'yes'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YycWxpa3BxVTZOS2FwNE44ejdibnk1bU1ZM3lsb3UyVnpaS2xmTnpMNVphU3FadVkyUT09"]
tags:
- Terror
---










