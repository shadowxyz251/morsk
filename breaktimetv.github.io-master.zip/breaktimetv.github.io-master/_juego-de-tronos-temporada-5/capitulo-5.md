---
layout: episodio
title: "Juego de Tronos 5x05"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-4'
proximo: 'capitulo-6'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cGRvV3FzOXEyM1hTUnJ5SHEyMWdlUmZCS2FIeUpyYjg3WkdXZ1R5aTlpS2NVbFRZZSs2cVZmQ050T09wY01uaGc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E05.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











