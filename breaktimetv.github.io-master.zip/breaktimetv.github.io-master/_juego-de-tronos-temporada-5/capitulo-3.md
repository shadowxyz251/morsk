---
layout: episodio
title: "Juego de Tronos 5x03"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-2'
proximo: 'capitulo-4'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6aG1iT1NRQmx4Y0dXaWI2Rk5SWlVwRXB3RnZVYll4Y1JPUW9meWgyQXA5dkl5OGh6aC9PVFJmL1JOOEJrV1VlbVE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E03.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











