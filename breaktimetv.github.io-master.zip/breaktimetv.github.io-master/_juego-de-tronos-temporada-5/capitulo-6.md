---
layout: episodio
title: "Juego de Tronos 5x06"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-5'
proximo: 'capitulo-7'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZyblZsbjYzVnVyZXhnYVptcnFQYnZiVitvcG12dU1tWnNLcW1ockxMNmFXU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











