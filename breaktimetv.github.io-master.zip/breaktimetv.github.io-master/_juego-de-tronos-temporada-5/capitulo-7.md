---
layout: episodio
title: "Juego de Tronos 5x07"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-6'
proximo: 'capitulo-8'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6Z05aR0ZtcWRBQlBwNC9iL1hMVUVUTXpLVW9pS3VibzIyeDdkZGpkbjhpUGFrYnptN0RaTTBBRGYvL1dQVlFaSmc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E07.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











