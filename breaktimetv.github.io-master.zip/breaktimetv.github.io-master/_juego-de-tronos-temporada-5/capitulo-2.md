---
layout: episodio
title: "Juego de Tronos 5x02"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6ckNzNEdjaFpObFluSWJWSXhGZ2NuaUVzL3ZtZVd0MkNSMFl4VUwzSVBJSmZTdkNLbTlZenpjY2Y5RFFhVnFrWkE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E02.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---










