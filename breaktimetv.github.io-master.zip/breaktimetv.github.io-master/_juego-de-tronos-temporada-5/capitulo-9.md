---
layout: episodio
title: "Juego de Tronos 5x09"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-8'
proximo: 'capitulo-10'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cW44UEF4Y0cxM2hYQldIRTk3OTNwaURNa0NRRW9ZaU1sY3ZtcTZKT1htNldMTk5oM0dWQkZMV0JMYkcrRHVBMVE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E09.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











