---
layout: episodio
title: "Juego de Tronos 5x10"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-9'
proximo: ''
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bmtBV1dTZXpodEVmQVd1TTlyZWEzNm1qQ1dsR1RSdUN3bmxHakN1OFg5RDNQZGtPY21RVW5TU0JCRXZ1QlRjcHc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E10.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











