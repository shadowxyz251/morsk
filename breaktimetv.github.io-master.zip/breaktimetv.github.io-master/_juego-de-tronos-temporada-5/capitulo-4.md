---
layout: episodio
title: "Juego de Tronos 5x04"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-3'
proximo: 'capitulo-5'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cGRvV3FzOXEyM1hTUnJ5SHEyMWdlU0hyeENOcGhLeTV2MFN4am0wcnFHZVh4eGF0WlpLaXpjR0YwWnJ1ZVZPc2c9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E04.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











