---
layout: episodio
title: "Juego de Tronos 5x08"
url_serie_padre: 'juego-de-tronos-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-7'
proximo: 'capitulo-9'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cW44UEF4Y0cxM2hYQldIRTk3OTNwaEM4T1VHQXdSVm9KcndXZkVBTVZQSTA4cll4TlgreHI3RmpDL29iUGtycnc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S05E08.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











