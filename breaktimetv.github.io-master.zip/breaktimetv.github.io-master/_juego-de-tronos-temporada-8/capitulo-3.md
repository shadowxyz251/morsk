---
layout: episodio
title: "Juego de Tronos 8x03"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-2'
proximo: 'capitulo-4'
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z5S3FWbTdQQXphKzllNGg4dDVQanhxeVZxSUhCcTdXMHpYbDBqSk9zNE5LU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











