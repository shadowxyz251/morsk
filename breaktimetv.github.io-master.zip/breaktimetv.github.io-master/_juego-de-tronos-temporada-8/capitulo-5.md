---
layout: episodio
title: "Juego de Tronos 8x05"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-4'
proximo: 'capitulo-6'
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z6cGRmcExmUHU1aXloMktGeEpHbXJzdXBvb0NZektERnRZQnBZTnZHcEpxU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











