---
layout: episodio
title: "Juego de Tronos 8x02"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0Sm1Dck1tdDJwblFtSGV0a3JqV25iYXFwV3Zhdzc2MnhIV0tpOHk2NTdhU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---










