---
layout: episodio
title: "Juego de Tronos 8x04"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-3'
proximo: 'capitulo-5'
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YySlNLbExMUDNzaTBtcXVWbU1YWm5OQmdkSC9acDliWXM2R1JoS3VPcXRpU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











