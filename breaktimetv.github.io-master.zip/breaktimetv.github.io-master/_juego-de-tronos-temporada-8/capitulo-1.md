---
layout: episodio
title: "Juego de Tronos 8x01"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZxWnVGZ01HbXlMR3pncFdTejYzQzFNeW5obWJOeHFESm0yeUdsNXZTNjk2U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











