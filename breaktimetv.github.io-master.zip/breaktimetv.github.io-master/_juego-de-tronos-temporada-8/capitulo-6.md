---
layout: episodio
title: "Juego de Tronos 8x06"
url_serie_padre: 'juego-de-tronos-temporada-8'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-5'
proximo: 'capitulo-7'
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0M3QxYWNIVnhkS2twWGlvcTVXMG1yTjJwWDZVeE9XbnU1Mm9kYzNiMVptU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











