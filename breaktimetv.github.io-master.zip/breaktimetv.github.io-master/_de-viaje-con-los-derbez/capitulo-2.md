---
layout: episodio
title: "De viaje con los derbez 1x02"
url_serie_padre: 'de-viaje-con-los-derbez'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
reproductores-google: ["https://lomasflex.com/VIDEOS/Series/Los%20Derbez/CAP2.mp4"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---










