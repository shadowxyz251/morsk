---
layout: episodio
title: "De viaje con los derbez 1x01"
url_serie_padre: 'de-viaje-con-los-derbez'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
reproductores-google: ["https://lomasflex.com/VIDEOS/Series/Los%20Derbez/CAP1.mp4"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











