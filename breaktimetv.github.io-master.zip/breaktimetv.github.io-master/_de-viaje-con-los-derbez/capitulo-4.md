---
layout: episodio
title: "De viaje con los derbez 1x04"
url_serie_padre: 'de-viaje-con-los-derbez'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2017'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores-google: ["https://lomasflex.com/VIDEOS/Series/Los%20Derbez/CAP4.mp4"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











