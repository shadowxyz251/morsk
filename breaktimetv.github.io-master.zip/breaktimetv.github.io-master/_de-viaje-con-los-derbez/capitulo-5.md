---
layout: episodio
title: "De viaje con los derbez 1x05"
url_serie_padre: 'de-viaje-con-los-derbez'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2017'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores-google: ["https://lomasflex.com/VIDEOS/Series/Los%20Derbez/CAP5.mp4"]
reproductor: onlystream
clasificacion: '+10'
tags:
- Comedia
---











