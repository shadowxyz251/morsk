# Framework Ruby On Rails
![Cover Image](https://res.cloudinary.com/imbriitneysam/image/upload/v1532562275/1_QAKgL2YNoLX6EEWBUxL8IA.png)

## ¿Qué es Ruby On Rails?

Ruby on Rails es un entorno de desarrollo web de código abierto que está optimizado para la satisfacción de los programadores y para la productividad sostenible. Te permite escribir un buen código evitando que te repitas y favoreciendo la convención antes que la configuración.


