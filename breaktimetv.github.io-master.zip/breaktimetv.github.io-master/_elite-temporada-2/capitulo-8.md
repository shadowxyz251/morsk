---
layout: episodio
title: "Élite - Temporada 2x08"
url_serie_padre: 'elite-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2019'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZwNENHbGRlcHV0Zlpwb3VybU0zYmxzS1NlS3V1dGRmSHJJV2VlTHJJckp1U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1567919047/Elite-temporada-2-castellano-online-min_a2xd2n.jpg'
tags:
- Drama
---










