---
layout: episodio
title: "Élite - Temporada 2x05"
url_serie_padre: 'elite-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2018'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0NWQ2ZnBLbXBLclRmM1I4azZib3Q3dWlhb1hTcnI2WHIyQ3BnYzZ2NDdLU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1567919047/Elite-temporada-2-castellano-online-min_a2xd2n.jpg'
tags:
- Drama
---











