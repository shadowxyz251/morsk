---
layout: episodio
title: "Élite - Temporada 2x02"
url_serie_padre: 'elite-temporada-2'
category: 'series'
anio: '2019'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZtSHltZnR1MTBxL1FwWHQzeGFQc2xzcXNmM1hTcnVIVHpvbVpsNWF2dThxU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1567919047/Elite-temporada-2-castellano-online-min_a2xd2n.jpg'
tags:
- Drama
---










