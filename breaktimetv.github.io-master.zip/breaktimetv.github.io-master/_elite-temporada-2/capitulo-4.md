---
layout: episodio
title: "Élite - Temporada 2x04"
url_serie_padre: 'elite-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZsWXlraWFpMnhaVFRnSlNybXNYZGxweUpwS0NXc05MRmxJTjJvTVhHNE4yU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1567919047/Elite-temporada-2-castellano-online-min_a2xd2n.jpg'
tags:
- Drama
---












