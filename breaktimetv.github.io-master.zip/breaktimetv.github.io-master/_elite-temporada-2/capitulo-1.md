---
layout: episodio
title: "Elite - Temporada 2x01"
url_serie_padre: 'elite-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductor: fembed
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YwS3VqZnMzRTZMWE1oSFJnc0pYSXU1bGdxcWF6eE9pZG02ZUFwOUxGNHM2U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1567919047/Elite-temporada-2-castellano-online-min_a2xd2n.jpg'
tags:
- Drama
---











