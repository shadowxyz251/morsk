---
layout: episodio
title: "La casa de las flores 2x08"
url_serie_padre: 'la-casa-de-las-flores-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2017'
proximo: 'capitulo-9'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0WVoxb1phTzN0R1ZxNTJWdk16Q25kU0NvWXJEa2FteXhwNWtpdHZhNGN5U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











