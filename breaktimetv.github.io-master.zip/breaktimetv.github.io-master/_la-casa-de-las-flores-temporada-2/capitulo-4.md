---
layout: episodio
title: "La casa de las flores 2x04"
url_serie_padre: 'la-casa-de-las-flores-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2017'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YwWnlHZjdPUnVMNnRkcFYrcDhmTHVybWRmNXl5c0tTV3BabUpvSzI2b0s2U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











