---
layout: episodio
title: "La casa de las flores 2x03"
url_serie_padre: 'la-casa-de-las-flores-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-2'
anio: '2017'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZwYVNHalpxVTI1ZkttSHFscXFUQzJMS0phWWJHejZqYTBXcXJxc21hdDdTU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











