---
layout: episodio
title: "Chernobyl 1x01"
url_serie_padre: 'chernobyl-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
fuente: 'cueva'
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560310449/chernobyl-banner-min_fgx16v.jpg'
reproductores: ["https://slave7.vanlong.stream/public/dist/index.html?id=3e5e2fa648de69718e6b249e8466b3a4&sub=https%3A%2F%2Fsub.cuevana2.io%2Fvtt-sub%2Fsub7%2FChernobyl.S01E01.vtt"]
tags:
- Drama
---











