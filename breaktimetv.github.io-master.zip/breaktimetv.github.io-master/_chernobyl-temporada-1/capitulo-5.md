---
layout: episodio
title: "Chernobyl 1x05"
url_serie_padre: 'chernobyl-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: 'capitulo-4'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: fembed
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560310449/chernobyl-banner-min_fgx16v.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YxM21rcDVpYXc4ZldoMktZc2JpbnlOV0dvSHVVeHNlenFhbWphS2FVcDdhU3FadVkyUT09"]
tags:
- Drama
---











