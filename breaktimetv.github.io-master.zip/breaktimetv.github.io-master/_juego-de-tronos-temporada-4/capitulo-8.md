---
layout: episodio
title: "Juego de Tronos 4x08"
url_serie_padre: 'juego-de-tronos-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-7'
proximo: 'capitulo-9'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6alh6SWxDZW1Xa1l2YmlUWHNCZDcxd3VJM1g0eHRsTkJaQ2FYV3o3YnpjVURsRTVVY3FVZEZuUlFPMjlxUkNVdHc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S04E08.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











