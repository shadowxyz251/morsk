---
layout: episodio
title: "Juego de Tronos 4x07"
url_serie_padre: 'juego-de-tronos-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-6'
proximo: 'capitulo-8'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cmJMQ0d6b2lwVnRVQ1VuelhIcW9MV09ZRkdYV21BSjc5OWFEWlM0emdWc3p4Zi81MHNiaURmZXN3c3Ava1BhSVE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S04E07.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











