---
layout: episodio
title: "Juego de Tronos 4x01"
url_serie_padre: 'juego-de-tronos-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6Z2R6QjcwZkhoNC9zK0JGMHFOekgvNDJFTmlSRGdHdW5zaGNKeGFRWVZteUk5eUs5a0pNMitHeXFyUjVOQU5lQUE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S04E01.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











