---
layout: episodio
title: "Juego de Tronos 4x09"
url_serie_padre: 'juego-de-tronos-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-8'
proximo: 'capitulo-10'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6c0tWR3B6MHpKdC8wd2ZxeDJkU2V6cDVpK3kzUng4b0Q0MWZ5TEE4ajdEeFdENEVVQUZYdHRmQTAzNDNodTR1a3c9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S04E09.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











