---
layout: episodio
title: "Juego de Tronos 4x04"
url_serie_padre: 'juego-de-tronos-temporada-4'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-3'
proximo: 'capitulo-5'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bTJDRWozS3JXMWkyNi9YekY4YnFwM2d2TzBWa1pkL2VGcXpkd0lIMjNJTm9tL0RuODZCOHhEbTk4Q1dIeVBQVFE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S04E04.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











