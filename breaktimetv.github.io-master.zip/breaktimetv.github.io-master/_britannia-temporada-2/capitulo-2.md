---
layout: episodio
title: "Britannia 2x02"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuSlBkNkRicm15dW9xSU00bnYxcWxFZC8xcEtrYlcwdU9QNXlHbFZHVk8razVOeSt3K1g5eC9BOVlqd1dhRVVDcXc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E02.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---










