---
layout: episodio
title: "Britannia 2x07"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-6'
proximo: 'capitulo-8'
anio: '2018'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuQ3lKdDZRMzRHREZtT2lRYkpTNGg5ZVJiZ1RPYkFvbjlLeGk2L1d1MlBPNERKa1BCT1pMdUhUSVlFVmo0ZlV3TEE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E07.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











