---
layout: episodio
title: "Britannia 2x05"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2018'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuT0RlMXBJREdTNE1GNld1b2ZnRUQvVXZ0eTE4cmc5cU14TDVETmY2ME5lVzJKUDM3Y3ZzTzBKMjBFTmhRNEZ0K1E9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E05.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











