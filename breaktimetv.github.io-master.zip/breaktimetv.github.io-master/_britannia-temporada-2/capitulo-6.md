---
layout: episodio
title: "Britannia 2x06"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-5'
anio: '2018'
proximo: 'capitulo-7'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuUEp4c3FpL2NrNEpNc1I5M3hSMnZpMm8xZmN0Y3hsMkFaR3N6ZjZiWWxTVUUyV3RjbDRKWHZRNzdWVnY4NzRqNXc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E06.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











