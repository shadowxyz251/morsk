---
layout: episodio
title: "Britannia 2x10"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-9'
anio: '2018'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuQmdRamFkSzJRbE8rZncxOXF6WnBnaHJJTms0TmlNa3hXTno1bzJjWmFGMDBOeWR4Z2NGeGlCYThXOExDbkhaVHc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E10.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











