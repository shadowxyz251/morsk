---
layout: episodio
title: "Britannia 2x03"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-2'
anio: '2018'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuTkMvSXdab1BOd0dJQ3RtUTArUUNnWnNiMXNIcENlcjNEQkhxNjUwbUN5UC9GdGl2b0NXbS8wSG5CU2UxUDYzOWc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E03.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











