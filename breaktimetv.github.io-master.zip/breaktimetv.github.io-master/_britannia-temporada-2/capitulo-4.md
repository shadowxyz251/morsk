---
layout: episodio
title: "Britannia 2x04"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2018'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuTEEvekkrUlBORTNOc0JKSnh1WWU5ejk2c3FydkpKanBnUUp5aFJ5SldhcCtWbTFycTMyeVFhK0VQVHBNMWFVWkE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E04.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











