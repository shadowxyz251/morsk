---
layout: episodio
title: "Britannia 2x08"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2018'
proximo: 'capitulo-9'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuR0ZEcm9hVmYwYUR5Z0Y3U3phOGMycUN1K0hmVE5SUVlZUHNlRGYwVlBva3Zvc2MrNXNWR2M0TFhuR1U0cDlJdWc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E08.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











