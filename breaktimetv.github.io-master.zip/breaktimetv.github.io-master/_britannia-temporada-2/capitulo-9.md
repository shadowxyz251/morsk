---
layout: episodio
title: "Britannia 2x09"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-8'
anio: '2018'
proximo: 'capitulo-10'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuTGZqTWhRRWh0U3YvdHVybDhKbXc2UnpadG0vVFpBMTY1MEFwTVk1amI1MExpK1NoYXdUWHlZb0NiRU1tamVEQ0E9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E09.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











