---
layout: episodio
title: "Britannia 2x01"
url_serie_padre: 'britannia-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuSjNqTStEWUgzYUNTYUdOTVlnbmQ5cWIxM2x4anUyVTRaQkhUYW96eXZUUEErNjUybXEycVNJN2NPbTVRNGEvMHc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Britannia.S02E01.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











