---
layout: episodio
title: "Britannia 1x03"
url_serie_padre: 'britannia-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-2'
anio: '2018'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductores: ["https://hls.pelis.cloud/public/dist/index.html?id=b4688d1893af72d85b5d36d3d0de590f"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











