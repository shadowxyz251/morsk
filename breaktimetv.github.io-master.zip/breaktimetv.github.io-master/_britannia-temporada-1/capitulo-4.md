---
layout: episodio
title: "Britannia 1x04"
url_serie_padre: 'britannia-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2018'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductores: ["https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJSbW02S2c"]
reproductor: 'fembed'
clasificacion: '+10'
tags:
- Fantasia
---











