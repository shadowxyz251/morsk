---
layout: episodio
title: "Britannia 1x01"
url_serie_padre: 'britannia-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductores: ["https://hls.pelis.cloud/public/dist/index.html?id=06666e3a39c7e805f3c760f38c667216"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











