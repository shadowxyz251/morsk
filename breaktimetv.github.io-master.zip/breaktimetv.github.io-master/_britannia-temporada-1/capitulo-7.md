---
layout: episodio
title: "Britannia 1x07"
url_serie_padre: 'britannia-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-6'
proximo: 'capitulo-8'
anio: '2018'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductores: ["https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJSbW02ZVk"]
reproductor: 'fembed'
clasificacion: '+10'
tags:
- Fantasia
---











