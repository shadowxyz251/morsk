---
layout: episodio
title: "Final Space 1x02"
url_serie_padre: 'final-space-temporada-1'
category: 'series'
anio: '2018'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductor: 'fembed'
reproductores: ["https://animekao.club/kaodrive/embed.php?data=VQZFLotfgqwo7VkDRK0H20zWWSQkYEcvTplkUv3Fby0f5bRDLcrXT5lkJpIQtKQ5W3TI5Yb/gm4TIc80F9jXdgNnZEIURxMfrpqXvLMlWcqMo+Bt9VypoaEM9s3pIinQbg0tr5N4/K9eTuIZ2qAr8u+rI4ZhwkXUcpU46zWz8raSRsYL58wXrVsn1vBg7L7T5rzJp3y9DjxFoL/f3h3RLRefrj5rPCYW0HbTYKvLItNCZ38Kx5gug4vmpiPNjb08JcCK0ily48zRbgkryUDo0EeY1pHgRJuei7ODL/CJBtg1yReROvD7QWiVNQICbUeNP3aXAh7M+S5f1g7qbYYu3PKI8dC6C4xJEzpQ6MKnDKpG84o00yBhKhchqardKQ3qF1Kx1Wu0GC1Yf1WSFsT1gg=="]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560736048/final-space-banner-min_fxzmcc.jpg'
tags:
- Animado
---










