---
layout: episodio
title: "Final Space 1x05"
url_serie_padre: 'final-space-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2018'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductor: 'fembed'
reproductores: ["https://animekao.club/kaodrive/embed.php?data=gEytQjdVcbYeuNgdsPp9V4SvIN/v91Uj//dL1Lkop2isr/V9L6yW327uifA7/IEq7kxmZv4L/1+pqNkGt2HbRycCK6W8XtrnYS20ts90S5rOVHn01CwprRRj2iy6gZ2ILWhAaB+40tYHSHPRdGikCZIRMcJn6tziGjokw3rePbtNsqBQGDeYqQhcPCSD0qjEoKjZkcww+1uDWvoDBX12lqt0Mavag0LBu9DcDJ4TG3Cz8Yq1ONyMCzOswIi6ZqO/BkiBFv/A3GlVM/nD/oQ3AP1cTUacRw6FWP71ilZa2wUgHAS0mh5WewLmPsCwup2hkJ8FqX5YRQhKveTTqpS3LnHG50+IwhfP99Cmm0tUhE4AMIESk3DcJ2D5TDLZ8FbPbE0Vn2/IdF74zHWe4W2Z1w=="]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560736048/final-space-banner-min_fxzmcc.jpg'
tags:
- Animado
---











