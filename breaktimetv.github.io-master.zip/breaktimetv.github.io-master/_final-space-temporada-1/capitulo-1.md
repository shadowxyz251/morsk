---
layout: episodio
title: "Final Space 1x01"
url_serie_padre: 'final-space-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductor: 'fembed'
reproductores: ["https://animekao.club/kaodrive/embed.php?data=DmPwUXFJfh3tixUoX+H7KrG5pyv3BJEA6Gq22CmDj1DgQt1AmzYrmRQEDxjfxG9MHJGw06bXgCnnY9GesiA2LP/D005BV59ZVsoINxTSNS7AeaAYZSx1O+p7RoRke62MYQs5Hg9bv5nHiqrTOe6RgP9N+CAb2JOzXYS5ZUSj0XR+6/wDIdK7vvUfVV4zHFOIzMxguaicDKHE+MgckBVuqrjy+Q7mmMT5rG7Mm11gCw0pdsY9pFwyJTSBKdtbzgN4fVS329zthDydF/X+sGS4o/k8T1P6vorcl4tElAAWCOk2mfo65CLob37R1fJy3orxZXcFNxl9yqXx2i+fmiyE8yewTB+ApTALtGqjkO7gI6IliabDqddVG+a0PFFHjlrMb7WCG8ssweLn+QyeZa65tg=="]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560736048/final-space-banner-min_fxzmcc.jpg'
tags:
- Animado
---











