---
layout: episodio
title: "La Casa de Papel 1x08"
url_serie_padre: 'la-casa-de-papel-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2017'
proximo: 'capitulo-9'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZwbXBvcXN5MXVwV3lkNk4vbDliV3lwcCtaYXlxcU15bTE1NkNmSnF4dzltU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---











