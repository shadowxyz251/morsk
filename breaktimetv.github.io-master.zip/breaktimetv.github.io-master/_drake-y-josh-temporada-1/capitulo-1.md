---
layout: episodio
title: "Drake y Josh 1x01"
url_serie_padre: 'drake-y-josh-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2004'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
reproductor: 'rapidvideo'
calidad: '480p'
reproductores: ["https://uqload.com/embed-1skr8ogtsuwb.html"]
tags:
- Comedia
---











