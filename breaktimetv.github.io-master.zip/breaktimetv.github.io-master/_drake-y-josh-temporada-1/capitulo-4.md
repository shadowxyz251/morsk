---
layout: episodio
title: "Drake y Josh 1x04"
url_serie_padre: 'drake-y-josh-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2004'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
reproductor: 'rapidvideo'
calidad: '480p'
reproductores: ["https://uqload.com/embed-ojbg0fje6st8.html"]
tags:
- Comedia
---












