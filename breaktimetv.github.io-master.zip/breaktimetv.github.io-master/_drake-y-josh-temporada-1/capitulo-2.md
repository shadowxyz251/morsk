---
layout: episodio
title: "Drake y Josh 1x02"
url_serie_padre: 'drake-y-josh-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2004'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
reproductor: 'rapidvideo'
calidad: '480p'
reproductores: ["https://uqload.com/embed-zb2vk7fx5xxz.html"]
tags:
- Comedia
---










