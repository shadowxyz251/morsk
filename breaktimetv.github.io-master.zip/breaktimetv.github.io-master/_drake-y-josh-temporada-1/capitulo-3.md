---
layout: episodio
title: "Drake y Josh 1x03"
url_serie_padre: 'drake-y-josh-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2004'
prev: 'capitulo-2'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
reproductor: 'rapidvideo'
calidad: '480p'
reproductores: ["https://uqload.com/embed-ikz49mntbn1j.html"]
tags:
- Comedia
---











