---
layout: episodio
title: "Juego de Tronos 7x02"
url_serie_padre: 'juego-de-tronos-temporada-7'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6aTcxd0RTSUw2YU5JY1RBSGUxMm5WT0RpdDFncGpMd3VTanlETVNmUkVwdTNKT2VvWXhxUS9SRHllT2x2cTF5TFE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S07E02.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---










