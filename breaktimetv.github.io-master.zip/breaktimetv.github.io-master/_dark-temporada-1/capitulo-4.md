---
layout: episodio
title: "Dark 1x04"
url_serie_padre: 'dark-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2017'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino/Subtitulado'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547164649/dark-banner-min.jpg'
reproductores: ["https://player.openplay.vip/player.php?id=Mjc3Nw","https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZtWHQ1ZDlpaXVNblplWHVvbEplcnpwZC9xbnUxcDlmSDJKV2NkOHFucEp1U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











