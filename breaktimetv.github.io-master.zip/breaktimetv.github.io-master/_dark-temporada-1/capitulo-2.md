---
layout: episodio
title: "Dark 1x02"
url_serie_padre: 'dark-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino/Subtitulado'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547164649/dark-banner-min.jpg'
reproductores: ["https://animekao.club/kaodrive/embed.php?data=wBRgdVKKoQFTUZqoWxAn75oFSxEUuYgXo0/7EvO1gvANoBqbKz8xrYrMt0ZtEyNy40fFm7MEs+S+Nkth8sV2zv4nMZ0nr2+BgQHeV+WOmKtz3eRRQ5lU96F+WGWkliN1t7yw4qglknza3A0fMNn0yiLpi8Y/2SsqFR2HpRVpKWGb4qCBq7opylYPwZGqayzUavv1imwmMhIHIUjqXc+rlXsgBWHGlo7SXc3yulKtXSJcl4+rCZFYqsU0uPCVxbmkMdFWXfbDW6U3mTHk6AiR5n09U5nObjAOh9EXdmsTleT8Az4NzJIXWviQc0HiMmA2ruOwQQxD9AGcoU2T2cG3QXt+t51x13Oa4EHpdmDs5p6focF3zwpK+wcR5lPWJ82WYbu0g0YOtL6zPSkMBWQeAAzm+YRHirtKLMyWX1yKu87e2tyeCM9uFwwI8EnCc45v79J3OqL/bZ/INBV0fqECFywa6aYtBDzCDbG2AiJD9is8Qri20l7JEtQcq62QnOnK","https://player.openplay.vip/player.php?id=Mjk1NA","https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJOaW9LQ1o","https://api.cuevana3.io/olpremium/gd.php?file=ek5lbm9xYWNrS0xNejZabVlkSFIyTkxQb3BPWDB0UFkwY3lvbjJIRjBPQ1QwNStUck1mVG9kVExvM0djeHA3VnFybXRscUdvMWRXNHRZbU1lYXVUeDg2cGpKVmp4cXpBejYxcGsyVE4xOWE2clhlSm5hU254TStjb0plZHE1VFdsSmlyaGFER3NzV1VzR2VHaXJEYjFzNjVmNVdIck5ySXpyVm5mNHE0cGNyU3g0MlVpdGFYeE5MSGk1Wmx0Sy9BMEsxL2dJcmFrc3JQeTR1RmlObVUxS3FvYklLRWlNbmYxOG1ZYjZ6SDFBPT0","https://api.cuevana3.io/stream/index.php?file=ek5lbm9xYWNrS0xYMTZLa2xNbkdvY3ZTb3BtZng4TGp6ZFpobGFMUGtOYk4yWnllWU5iVDJNWFhZR1JtazVxa2xKR1VvcVBWMGVMWWtaYWhvSkhWNTVtYWFHVnJsNWZTdDdoMWdwS3FwZEszazJTUmVKS1RvZEhUWjNHajBkVG53OWVzb3BpZjFOald6Smc9","https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YwcXVkZmEzUzFhaTFnV09qbWNDbDE4eG1kM21aMnRmVzBuYWFhTWpYcTlXU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---










