---
layout: episodio
title: "Dark 1x03"
url_serie_padre: 'dark-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-2'
anio: '2017'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Latino/Subtitulado'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547164649/dark-banner-min.jpg'
reproductores: ["https://player.openplay.vip/player.php?id=Mjk1Mw","https://api.cuevana3.io/stream/index.php?file=ek5lbm9xYWNrS0xYMTZLa2xNbkdvY3ZTb3BtZng4TGp6ZFpobGFMUGtOYk4yWnllWU5iVDJNWFhZR1JtazVxa2xKR1VvcVBWMGVMWWtaYWhvSkhWNTVtYWFHVnJsNWZTdDdoMWdwS3FwZEszazJTUmVKS1VvZEhUWjNHajBkVG53OWVzb3BpZjFOald6Smc9"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











