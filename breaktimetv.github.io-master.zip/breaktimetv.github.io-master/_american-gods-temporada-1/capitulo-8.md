---
layout: episodio
title: "American Gods 1x08"
url_serie_padre: 'american-gods-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2017'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z6S0Zubk1UYnhLaW5sWXA5eTlLMXo5T01nbm1wdU5XMHJwMXppTlBWcVppU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546556402/gods-banner-min.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











