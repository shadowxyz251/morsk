---
layout: episodio
title: "Batwoman 1x02"
url_serie_padre: 'batwoman-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuQ085TC9ua0ZNL0JETkovVjBMYjBiUVBzckVmNTNvNDhjUVVGeWhMcGdnNklycnBBZFlMTzdzL2UwaFFiVjRrakE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Batwoman.01E02.vtt","https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJoa29hRT0","https://api.cuevana3.io/olpremium/gd.php?file=ek5lbm9xYWNrS0xNejZabVlkSFIyTkxQb3BPWDB0UFkwY3lvbjJIRjBPQ1QwNStUck1mVG9kVExvM0djeHA3VnFybXRscUdvMWRXNHRZbU1lYXVUeDg2cGpKVmp4cXpBejYxcGxLMmowOWJQdWEyVWk2eVV6WmZIcUlobXpzdlh1NzJCakdha3E4SFAxNHVGaDdDVDFLakhwWmVIczVUR2w4WmpsR1BKMk1HV3JZcCtaYS9ZeVpUT3JZT2cxZHJGME11TmhHYk9xY3E4c1lXSGl0clF2cGZHYklLRWlNbmYxOG1ZYjZ6SDFBPT0","https://player.openplay.vip/player.php?id=MjMx&sub=https://sub.cuevana2.io/vtt-sub/sub7/Batwoman.01E02.vtt","https://api.cuevana3.io/stream/index.php?file=ek5lbm9xYWNrS0xYMTZLa2xNbkdvY3ZTb3BtZng4TGp6ZFpobGFMUGtOVEx6SitYWU5YTTdORE1vWmRnbEpham5KTmtZSlRTMGViVTBxZGdsdEhPb3RqWGEybGtsSk9qbU1LR2gzV3l3THVvd29aaVpNR21vNWFSb0tKbm9kSGkxOWVTcHF6U3hyRFh5S1dibUE9PQ","https://player.cuevana2.io/irgotoolp.php?url=eTllbW9hZHpYNURLejlaalg2T3BsYy9PMHNTV29hYWVuY3JYMEpHVm9LRm9uWlRYbTVKL201ZXdmZGlRMEphbmFRPT0&sub=https://sub.cuevana2.io/vtt-sub/sub7/Batwoman.01E02.vtt","https://api.cuevana3.io/stream/index.php?file=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z4S1NsaGMvQ3JKVzZnNENTdzhERHlhVjVkV1BjbDd1NXEzeW1hOFBJdEx5U3FadVkyYURhMDlLYW5walN5ZUxZMHFadnJNZlU","https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z4S1NsaGMvQ3JKVzZnNENTdzhERHlhVjVkV1BjbDd1NXEzeW1hOFBJdEx5U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---