---
layout: episodio
title: "Los caballeros del zodiaco 1x02"
url_serie_padre: 'caballeros-del-zodiaco-saint-seiya-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductor: 'fembed'
reproductores: ["https://animekao.club/kaodrive/embed.php?data=Q8RZJdctYSrg0SIjtEBS9UsffhY1csOl2dxQv8+wLlCvG/Nxp6rVBqNc7IwdsozwU2Q+46rUzv9vaDLMiogqxk1SeGMPOA7nFynq86uV5TGgoEi6WJASC2fQOLeuglL8dFL+PMafmRJiUjXSdbe+oC90/TwkkgW9pyKaHgnDRgwezyEX4zJPkl6zO18dBP198T9EJCvjIwiX+4zh5k0INPx2Lkhoz9Bz4Er7/MS+w0QF8JdFEV5cqI+/84/INHXrC3nnHzAigIKfQ09neOr8RBwJFLH0HefRpBvPbqYhzWRrXuxugT1YNI57GZu2pV4uZ24svcvOQPtL4SZJURQrW75gMf7u5JvKUnfmwz7J3/EWv4g7cXW8x1tFeWoEC1BlTfTBVaCZHka4R6rpZJKpqTVpMrrI6vIPy0ABninrtUMrqwwBIQ0grmp39XrHyC494hBVItVOk6CrYKPEHKwjAJabw8ygL3J/w+qgRo6PpidxcOPipnnQaBjSXdxm9G/F6+54UzflFepm4+uau8gdkA==","https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJab29xUT0"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1564459651/caballeros-banner-min_sw0slb.jpg'
tags:
- Animado
---










