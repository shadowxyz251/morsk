---
layout: episodio
title: "Desencanto 1x05"
url_serie_padre: 'desencanto-temporada-1'
reproductor: 'fembed'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2018'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductor: 'rapidvideo'
reproductores: ["https://uqload.com/embed-d1viya0trb1w.html"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1560736048/final-space-banner-min_fxzmcc.jpg'
tags:
- Animado
---











