---
layout: episodio
title: "Drácula 1x03"
url_serie_padre: 'dracula-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2020'
prev: 'capitulo-2'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://www.ilovefembed.best/v/kerqxt3j5n2g0r8"]
tags:
- Terror
---











