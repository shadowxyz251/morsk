---
layout: episodio
title: "Drácula 1x01"
url_serie_padre: 'dracula-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano/Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://www.ilovefembed.best/v/mx1qgh5461rzx03","https://www.ilovefembed.best/v/lypq8cnz38rqerx"]
tags:
- Terror
---











