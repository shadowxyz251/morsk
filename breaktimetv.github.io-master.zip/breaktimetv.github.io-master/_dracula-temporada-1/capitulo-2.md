---
layout: episodio
title: "Drácula 1x02"
url_serie_padre: 'dracula-temporada-1'
category: 'series'
anio: '2017'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://www.ilovefembed.best/v/3gxnpsm63kze3y4"]
tags:
- Terror
---










