---
layout: episodio
title: "Black Mirror 3x05"
url_serie_padre: 'black-mirror-temporada-3'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: 'capitulo-4'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductor: fembed
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0blJrZnMzRXZOVEhlSE4yMThmaG1wWmxlWjZqanFYWjJKNnBqYTJUN04yU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402294/black-3-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











