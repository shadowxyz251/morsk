---
layout: episodio
title: "Black Mirror 3x02"
url_serie_padre: 'black-mirror-temporada-3'
category: 'series'
anio: '2017'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YySmRpZjZQRndkMnpxSGVoMTdYZGw5Q25ubnpjcHFPK3haK01sYmkwNDV5U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402294/black-3-banner-min.jpg'
tags:
- Ciencia-Ficcion
---










