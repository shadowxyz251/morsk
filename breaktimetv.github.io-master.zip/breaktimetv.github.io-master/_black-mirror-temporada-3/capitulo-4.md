---
layout: episodio
title: "Black Mirror 3x04"
url_serie_padre: 'black-mirror-temporada-3'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0bVNNbmErbXVkblllbXQ4c2JmQTE5dW9mNG5hcWF5eXVXbC9qTml0MzkyU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402294/black-3-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











