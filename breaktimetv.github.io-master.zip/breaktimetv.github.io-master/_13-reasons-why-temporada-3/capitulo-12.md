---
layout: episodio
title: "13 Reasons Why 3x12"
url_serie_padre: '13-reasons-why-temporada-3'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-11'
anio: '2018'
proximo: 'capitulo-13'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1566688006/13reasonswhyseason3-min_fwmlxz.jpg'
reproductores: ["https://cdn3.openloadpremium.com/public/dist/index.html?id=f646d08d26ce06ef58d5f840052acee1"]
tags:
- Drama
---










