---
layout: episodio
title: "13 Reasons Why 3x02"
url_serie_padre: '13-reasons-why-temporada-3'
category: 'series'
anio: '2018'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1566688006/13reasonswhyseason3-min_fwmlxz.jpg'
reproductores: ["https://cdn3.openloadpremium.com/public/dist/index.html?id=5e63fc921151113453bebe2d9ae4d149"]
tags:
- Drama
---










