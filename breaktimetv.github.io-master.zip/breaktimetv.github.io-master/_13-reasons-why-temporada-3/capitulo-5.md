---
layout: episodio
title: "13 Reasons Why 3x05"
url_serie_padre: '13-reasons-why-temporada-3'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2018'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1566688006/13reasonswhyseason3-min_fwmlxz.jpg'
reproductores: ["https://cdn3.openloadpremium.com/public/dist/index.html?id=f337dc973ac93dc85b1fc2c26ae5d263"]
tags:
- Drama
---











