---
layout: episodio
title: "13 Reasons Why 3x01"
url_serie_padre: '13-reasons-why-temporada-3'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
image_banner: 'https://res.cloudinary.com/dmsdzouoo/image/upload/v1566688006/13reasonswhyseason3-min_fwmlxz.jpg'
reproductores: ["https://cdn3.openloadpremium.com/public/dist/index.html?id=5db3bc74e18b875c4035adcb894e12b0"]
tags:
- Drama
---











