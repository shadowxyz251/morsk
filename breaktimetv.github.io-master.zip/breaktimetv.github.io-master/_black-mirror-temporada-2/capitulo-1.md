---
layout: episodio
title: "Black Mirror 2x01"
url_serie_padre: 'black-mirror-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2013'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductor: fembed
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z4Wm1ib055eDQ5R3lwNkdzMkpIcWxaV0huS2JHeU1XNnFhcHpqS1BEMjZxU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402297/black-2-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











