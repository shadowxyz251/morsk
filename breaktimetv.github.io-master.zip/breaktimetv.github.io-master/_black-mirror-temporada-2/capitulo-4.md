---
layout: episodio
title: "Black Mirror 2x04"
url_serie_padre: 'black-mirror-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2013'
prev: 'capitulo-3'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores-google: ["https://www.fembed.com/v/058qxalwz5mp4ex"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402297/black-2-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











