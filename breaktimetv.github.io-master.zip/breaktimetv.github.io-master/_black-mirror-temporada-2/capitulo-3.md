---
layout: episodio
title: "Black Mirror 2x03"
url_serie_padre: 'black-mirror-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2013'
prev: 'capitulo-2'
proximo: 'capitulo-4'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZsMzVpb01XbHY1Mm9xSVJvMDdQcTA4bUZlV2VWdXNIRHlIOTZpS3lqb0t5U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402297/black-2-banner-min.jpg'
tags:
- Ciencia-Ficcion
---











