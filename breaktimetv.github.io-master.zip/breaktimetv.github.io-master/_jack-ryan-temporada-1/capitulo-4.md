---
layout: episodio
title: "Jack Ryan 1x04"
url_serie_padre: 'jack-ryan-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductor: 'fembed'
reproductores: ["https://hls.pelis.cloud/public/dist/index.html?id=076c584f08ee026e9b524a5ccdc89447"]
tags:
- Accion
---











