---
layout: episodio
title: "Élite - Temporada 1 - Capítulo 2"
url_serie_padre: 'elite-temporada-1'
category: 'series'
anio: '2018'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZtNGFDbExlNDJybVFvSitDMkpqRno2MlpjNTZ1bGJ5OXo0T01oc211cWNPU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546279806/elite-banner-min.jpg'
tags:
- Drama
---










