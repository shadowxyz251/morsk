---
layout: episodio
title: "Élite - Temporada 1 - Capítulo 1"
url_serie_padre: 'elite-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
reproductor: fembed
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZsbXlxZE5yVDZhaXJpNWQycExuWjJidVZvWGZLcWQyZHlwWmxkdHJDcWRHU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546279806/elite-banner-min.jpg'
tags:
- Drama
---











