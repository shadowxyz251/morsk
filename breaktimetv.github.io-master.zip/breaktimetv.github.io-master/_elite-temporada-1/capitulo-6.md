---
layout: episodio
title: "Elite - Temporada 1 - Capítulo 6"
url_serie_padre: 'elite-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-5'
proximo: 'capitulo-7'
anio: '2018'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZrMzZDb0pxanhiTzRySXAzc3BlOTFweGdpMm1YdHNqR21xMmpaWkt3NGR5U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546279806/elite-banner-min.jpg'
tags:
- Drama
---












