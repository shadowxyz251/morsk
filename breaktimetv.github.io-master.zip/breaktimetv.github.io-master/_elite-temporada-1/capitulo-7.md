---
layout: episodio
title: "Elite - Temporada 1 - Capítulo 7"
url_serie_padre: 'elite-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-6'
proximo: 'capitulo-8'
anio: '2018'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZsSWQ4Z2FUWnZMRFdmb2VycWRxNHc1eVNncW1VenFUYTNLWm9hYlBDcTl1U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546279806/elite-banner-min.jpg'
tags:
- Drama
---











