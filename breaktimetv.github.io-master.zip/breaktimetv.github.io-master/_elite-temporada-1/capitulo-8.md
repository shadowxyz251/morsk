---
layout: episodio
title: "Elite - Temporada 1 - Capítulo 8"
url_serie_padre: 'elite-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2018'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z5NmlSYXByT3VNeXNySmxvdTZxcXVadHNuWVNwa3Q2cnJvdWlZTEdremE2U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546279806/elite-banner-min.jpg'
tags:
- Drama
---










