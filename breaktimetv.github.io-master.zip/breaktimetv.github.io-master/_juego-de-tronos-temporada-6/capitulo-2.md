---
layout: episodio
title: "Juego de Tronos 6x02"
url_serie_padre: 'juego-de-tronos-temporada-6'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6dEpENWpORnpxWmljcDlyOTBkaTF0UVZ2bDR0UFJDK1o1TTQ1NDNCNGFmKy9iNWNxOE5FNlVKenMzNFJiZHFMMVE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S06E02.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---










