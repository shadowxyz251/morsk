---
layout: episodio
title: "Club de Cuervos 1x13"
url_serie_padre: 'club-de-cuervos-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-12'
anio: '2015'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://embed.pelisplus.movie/play?id=MTc0NTE=&option=latin"]
reproductor: 'fembed'
tags:
- Comedia
---










