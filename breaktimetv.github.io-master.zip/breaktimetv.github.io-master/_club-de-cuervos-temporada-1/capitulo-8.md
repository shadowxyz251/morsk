---
layout: episodio
title: "Club de Cuervos 1x08"
url_serie_padre: 'club-de-cuervos-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2015'
proximo: 'capitulo-9'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://embed.pelisplus.movie/play?id=MTc0NDE=&option=latin"]
reproductor: 'fembed'
tags:
- Comedia
---










