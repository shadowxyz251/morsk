---
layout: episodio
title: "Club de Cuervos 1x04"
url_serie_padre: 'club-de-cuervos-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2015'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJOa25KK1k"]
reproductor: 'fembed'
tags:
- Comedia
---












