---
layout: episodio
title: "Club de Cuervos 1x12"
url_serie_padre: 'club-de-cuervos-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-11'
anio: '2015'
proximo: 'capitulo-13'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJOa25xYWE"]
reproductor: 'fembed'
tags:
- Comedia
---










