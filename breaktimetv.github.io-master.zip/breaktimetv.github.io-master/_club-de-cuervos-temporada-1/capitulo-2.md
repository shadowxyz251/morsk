---
layout: episodio
title: "Club de Cuervos 1x02"
url_serie_padre: 'club-de-cuervos-temporada-1'
category: 'series'
anio: '2015'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductores: ["https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJscW5LYz0"]
reproductor: 'fembed'
tags:
- Comedia
---










