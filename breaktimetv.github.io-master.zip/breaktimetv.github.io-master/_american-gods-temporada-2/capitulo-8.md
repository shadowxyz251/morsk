---
layout: episodio
title: "American Gods 2x08"
url_serie_padre: 'american-gods-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-7'
anio: '2019'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z2WldFaUt2S3diR3lsSUNsdDdXN3FhdG1mSTNjbWV5NHoyT2ZuWmVqek15U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1562460529/god2-banner-min_eoromk.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---











