---
layout: episodio
title: "American Gods 2x02"
url_serie_padre: 'american-gods-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZwWlI2aEpYUjRiYlRZM09jczhicHhhWjlnWnZRbXVlbHhJWjdtcWVuNTlPU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1562460529/god2-banner-min_eoromk.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Ciencia-Ficcion
---










