---
layout: episodio
title: "Juego de Tronos 3x05"
url_serie_padre: 'juego-de-tronos-temporada-3'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-4'
proximo: 'capitulo-6'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6c1RpTTdsbVVWVVRQTVNVWjdiV3Avcy9rNi96TXIycWs5aVZFZGNjeEl0QlNBQkdtMzJKNWpWemoyTmlIdzhVOEE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S03E05.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











