---
layout: episodio
title: "Juego de Tronos 3x07"
url_serie_padre: 'juego-de-tronos-temporada-3'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-6'
proximo: 'capitulo-8'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cnl5Q3ppMGJUSTJyQ3dGRFJaNkpTRitBL2JkUE1zWkJpRW5qUjh4TEFid2lUTHg5STRRbW96dWxIcHIwYW5Pd2c9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S03E07.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











