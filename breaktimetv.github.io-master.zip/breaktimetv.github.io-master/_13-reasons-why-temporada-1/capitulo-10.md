---
layout: episodio
title: "13 Reasons Why 1x10 Latino"
url_serie_padre: '13-reasons-why-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-9'
anio: '2017'
proximo: 'capitulo-11'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Zsb1I2bjlUTG9MaXFoNmQweDVPMTI5bDVjNHJEeGNQYnJJeVlpYk8zNUplU3FadVkyUT09"]
tags:
- Drama
---










