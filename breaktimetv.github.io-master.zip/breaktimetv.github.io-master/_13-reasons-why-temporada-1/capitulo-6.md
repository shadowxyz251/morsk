---
layout: episodio
title: "13 Reasons Why 1x06 Latino"
url_serie_padre: '13-reasons-why-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-5'
proximo: 'capitulo-7'
anio: '2017'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z6SHg2ZmNXUzV0U2JaS1dObWM2Z3RaTmxnSGUybHNQRmxLWjBncGZIMkthU3FadVkyUT09"]
tags:
- Drama
---












