---
layout: episodio
title: "13 Reasons Why 1x02 Latino"
url_serie_padre: '13-reasons-why-temporada-1'
category: 'series'
anio: '2017'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason1-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZzcVZrZ1piVXBkdklyYVNhcUxUaDNkU0NwbjJ5eWVpMXphU3NoYS9LMU02U3FadVkyUT09"]
tags:
- Drama
---










