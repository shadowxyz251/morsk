---
layout: episodio
title: "Black Mirror 5x01"
url_serie_padre: 'black-mirror-temporada-5'
category: 'series'
capitulo: 'yes'
anio: '2016'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
calidad: 'Full HD'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0NXlEZDY2bnU3UzhtMlNXeWNTMTI3eHBnWXpSbHJiZWtKMkZtWSsxd3RhU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1562453397/black-5-min_c6urlh.jpg'
tags:
- Ciencia-Ficcion
---











