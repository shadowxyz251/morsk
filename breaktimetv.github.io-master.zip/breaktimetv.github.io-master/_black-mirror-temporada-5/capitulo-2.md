---
layout: episodio
title: "Black Mirror 5x02"
url_serie_padre: 'black-mirror-temporada-5'
category: 'series'
anio: '2016'
capitulo: 'yes'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Latino'
reproductor: fembed
calidad: 'Full HD'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Ztb3FvbDdhUzNkQ2tySnVrbEx2aXI5U1hvMlBEeEt1OXZHeVhwTlhYNDY2U3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1562453397/black-5-min_c6urlh.jpg'
tags:
- Ciencia-Ficcion
---










