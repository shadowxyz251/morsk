---
layout: episodio
title: "13 Reasons Why 2x13 Latino"
url_serie_padre: '13-reasons-why-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-12'
anio: '2018'
proximo: ''
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason2-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZtNEtscHE3VXd0SzFwYVpxdUx2dHJKQ3NoMmVhbWIyd3ZhbW9xcGlrM3BHU3FadVkyUT09"]
tags:
- Drama
---










