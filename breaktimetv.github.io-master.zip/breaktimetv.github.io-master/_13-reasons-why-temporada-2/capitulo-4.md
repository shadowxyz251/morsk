---
layout: episodio
title: "13 Reasons Why 2x04 Latino"
url_serie_padre: '13-reasons-why-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: 'capitulo-3'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
reproductor: 'fembed'
calidad: 'Full HD'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546545022/reason2-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z0YVZmZ2JqRnhzZXFlb0tGeUpuTWxacU1wNG5hbU0zYTA2bGZlcXpWdEtlU3FadVkyUT09"]
tags:
- Drama
---












