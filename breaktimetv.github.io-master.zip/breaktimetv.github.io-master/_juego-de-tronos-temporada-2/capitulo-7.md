---
layout: episodio
title: "Juego de Tronos 2x07"
url_serie_padre: 'juego-de-tronos-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-6'
proximo: 'capitulo-8'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6dkVyaUFPbHBTNGJ1RUJ3L2VPZEllQnkvRTdCVEFxN0xjTHZza0U5eXJnejdVR3lXUlZ4ejJSTnBta1hBTURuYmc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S02E07.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











