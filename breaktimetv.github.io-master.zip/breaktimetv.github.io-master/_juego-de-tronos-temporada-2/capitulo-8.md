---
layout: episodio
title: "Juego de Tronos 2x08"
url_serie_padre: 'juego-de-tronos-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-7'
proximo: 'capitulo-9'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bS9sZmJzaVJEZDdrV3E1bmtwLzQvNjlyaFp5OG5PdTZld3dkU3lkLzVjdEF1UU5QT2x6Y3M0V2tydWJIQU5CUFE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S02E08.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











