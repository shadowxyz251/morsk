---
layout: episodio
title: "Juego de Tronos 2x01"
url_serie_padre: 'juego-de-tronos-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bE5kcGxVZk1yWlhvL0UvRTVFWU45L0ZadVdjaGs2REVNRU12K0g4U2pHVG5MU2VMcGJXUnZMbDVjRjAyeGRMQUE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S02E01.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











