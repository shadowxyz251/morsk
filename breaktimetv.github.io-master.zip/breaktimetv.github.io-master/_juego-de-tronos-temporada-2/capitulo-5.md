---
layout: episodio
title: "Juego de Tronos 2x05"
url_serie_padre: 'juego-de-tronos-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-4'
proximo: 'capitulo-6'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6andRNlU1NTBvYloxZ1gzMitwMTYwUXZjOUFIOFVqK052WlVpbXhNS2txeDl2cWw4ckFpcnBBUWphM0VKdEIvWXc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S02E05.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











