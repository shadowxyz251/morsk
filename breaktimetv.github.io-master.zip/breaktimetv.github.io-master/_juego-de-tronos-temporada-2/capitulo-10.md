---
layout: episodio
title: "Juego de Tronos 2x10"
url_serie_padre: 'juego-de-tronos-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-9'
proximo: ''
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6dmtxOHJ3YUw3RG1VWEpQL1ZrWitWWmhnbWlkcXF0Y1I1R1BXcnBMc0hINkE5RjBwRTkrWGpJclpnd29iMmV4bVE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S02E10.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











