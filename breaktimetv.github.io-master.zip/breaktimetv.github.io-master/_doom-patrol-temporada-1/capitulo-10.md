---
layout: episodio
title: "Doom Patrol 1x10"
url_serie_padre: 'doom-patrol-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-9'
anio: '2017'
proximo: 'capitulo-11'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z5SlI4aktPd3U4eVlxS210ekx2ZjBhbDBkM1cwdDhxc3VaYVlsS3ZZeGRHU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1564118443/doom-patrol-banner-min_fds0b1.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---











