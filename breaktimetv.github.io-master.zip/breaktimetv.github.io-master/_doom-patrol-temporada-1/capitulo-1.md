---
layout: episodio
title: "Doom Patrol 1x01"
url_serie_padre: 'doom-patrol-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z5M2FuZHFXdXdhclFwNENteXJuWTNKeUJvbVNvMStUUHNYdXJsYS9VeXRXU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1564118443/doom-patrol-banner-min_fds0b1.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---











