---
layout: episodio
title: "Doom Patrol 1x02"
url_serie_padre: 'doom-patrol-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2019'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YyWnFLZWEreDFxVzJvcDFzeU5XL3ZyVjJpNTY1cDhXWXo0T2xyYSt6dDhhU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1564118443/doom-patrol-banner-min_fds0b1.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---










