---
layout: episodio
title: "Doom Patrol 1x14"
url_serie_padre: 'doom-patrol-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-13'
anio: '2017'
proximo: 'capitulo-15'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YybVYwcWFXNG84V25vV21JMEtTbW1MeURjMzJwcExTN2xhS3BlYTZ2NXNlU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/u4innovation/image/upload/v1564118443/doom-patrol-banner-min_fds0b1.jpg'
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---











