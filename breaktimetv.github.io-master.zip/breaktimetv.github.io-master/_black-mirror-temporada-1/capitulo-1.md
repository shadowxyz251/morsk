---
layout: episodio
title: "Black Mirror 1x01"
url_serie_padre: 'black-mirror-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductor: fembed
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1Z6SVNyaUxiUTNOYXlnWGVObDdESnQ4eWRZbmZOdEtuVHRheWxwTnZIdGRxU3FadVkyUT09"]
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1547402294/black-banner-1-min.jpg'
tags:
- Ciencia-Ficcion
---











