---
layout: episodio
title: "La Casa de Papel 2x02"
url_serie_padre: 'la-casa-de-papel-temporada-2'
category: 'series'
capitulo: 'yes'
anio: '2018'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638641/casa-2-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1YyNFdScWFlTzI3UENlWDFtcDQ3V3VkV1lxM1dvMUtUR3BKMkhocW1SeU51U3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---










