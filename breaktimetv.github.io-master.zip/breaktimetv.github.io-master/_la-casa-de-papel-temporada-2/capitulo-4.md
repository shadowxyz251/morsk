---
layout: episodio
title: "La Casa de Papel 2x04"
url_serie_padre: 'la-casa-de-papel-temporada-2'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-3'
anio: '2018'
proximo: 'capitulo-5'
sandbox: allow-same-origin allow-forms
idioma: 'Castellano'
calidad: 'Full HD'
fuente: 'cueva'
image_banner: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638641/casa-2-banner-min.jpg'
reproductores: ["https://api.cuevana3.io/rr/gd.php?h=ek5lbm9xYWNrS0xJMVp5b21KREk0dFBLbjVkaHhkRGdrOG1jbnBpUnhhS1ZyNk5yZXFTbjFNYk1hWUZxbXF5K3NyZDFuNG5NeWNqT3U2Rm1ucXlXNDgrU3FadVkyUT09"]
reproductor: fembed
clasificacion: '+10'
tags:
- Accion
---











