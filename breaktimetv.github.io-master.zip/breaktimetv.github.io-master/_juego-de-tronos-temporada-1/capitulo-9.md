---
layout: episodio
title: "Juego de Tronos 1x09"
url_serie_padre: 'juego-de-tronos-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-8'
proximo: 'capitulo-10'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bE5kcGxVZk1yWlhvL0UvRTVFWU45OHIxWVhkSVQvTHdTck5lV2xNSkt4eFk0aFRLVlVDcDNVUDNqUHRRZ096VGc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S01E09.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











