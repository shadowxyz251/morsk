---
layout: episodio
title: "Juego de Tronos 1x08"
url_serie_padre: 'juego-de-tronos-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-7'
proximo: 'capitulo-9'
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6c0hrdGtZMm5QeHV6aHBWV0o1MkJtOTVsNmdOSUphbjdMbVhZZTFxWURWYnF2UmxjZ01MWmhkZVQrVEpnbXBZMXc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S01E08.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











