---
layout: episodio
title: "Juego de Tronos 1x10"
url_serie_padre: 'juego-de-tronos-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: 'capitulo-9'
proximo: ''
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6cnBWMHYrQXdac2RkL0VkNHlDMGsyMjVxcjFWY2xlVHFOaDhjUEdzbHp1SW0zNnUxTTMvajUySVMwVHpweS93SWc9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S01E10.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











