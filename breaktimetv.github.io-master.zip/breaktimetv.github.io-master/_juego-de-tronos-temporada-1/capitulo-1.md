---
layout: episodio
title: "Juego de Tronos 1x01"
url_serie_padre: 'juego-de-tronos-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2011'
prev: ''
proximo: 'capitulo-2'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=bFVzdnFtbTRVZFI2TjFYc0dKMkJ6bndNNU9yb3IvTkpMNnpTNklxQW4zWUlqY29LRWtNa0pyR2FQd2Q1b2YxM0R3dzFXWTUzRVNtYmM2SE9Qa2ZNRlE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Game.Of.Thrones.S01E01.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Fantasia
---











