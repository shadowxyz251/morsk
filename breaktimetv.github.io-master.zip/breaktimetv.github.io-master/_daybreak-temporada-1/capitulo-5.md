---
layout: episodio
title: "DayBreak 1x05"
url_serie_padre: 'daybreak-temporada-1'
category: 'series'
capitulo: 'yes'
prev: 'capitulo-4'
anio: '2017'
proximo: 'capitulo-6'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
image_carousel: 'https://res.cloudinary.com/imbriitneysam/image/upload/v1546638640/casa-papel-1-poster-min.jpg'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuQ0Q0Q0JtTzlZWFFOOTJ4Yk1WUnRDTmM5SEpKTGpNSkFIUlFrMU41dW9ESUx5MDBvT3lUazU3NmkzL2VEdTRhWEE9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Daybreak.S01E05.vtt","https://player.cuevana2.io/irgotoolp.php?url=eTllbW9hZHpYNURLejlaalg2T3BsYy9PMHNTV29hYWVuY3JYMEpHVm9LRm9uWlRYbTVKL201K3dmNktRMEphbmFRPT0&sub=https://sub.cuevana2.io/vtt-sub/sub7/Daybreak.S01E05.vtt","https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJabW9hV2I"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---











