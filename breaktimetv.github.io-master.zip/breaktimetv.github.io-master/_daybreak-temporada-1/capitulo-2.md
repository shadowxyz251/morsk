---
layout: episodio
title: "DayBreak 1x02"
url_serie_padre: 'daybreak-temporada-1'
category: 'series'
capitulo: 'yes'
anio: '2017'
prev: 'capitulo-1'
proximo: 'capitulo-3'
sandbox: allow-same-origin allow-forms
idioma: 'Subtitulado'
calidad: 'Full HD'
fuente: 'cueva'
reproductores: ["https://hls4.openloadpremium.com/player.php?id=dFVTd3dyMXN5dVJENEh0cUNJN0JuSnQwOXBzMnNzNExaRUN4WjJWV2w3WXF2Zm53NTlndnIrSzhtUXNIaGZSZ00reFlEd2RkbTRwbFFqVnRIMGRFL0E9PQ&sub=https://sub.cuevana2.io/vtt-sub/sub7/Daybreak.S01E02.vtt","https://tutumeme.net/embed/player.php?u=bXQ3ajJOaW1wcFRGcEs2VW5XRGExTlRPMytmUnc3bHVwcWhoenVIUjI5SHF5TlNwc0taaG1jN2gwZHZSNTlIRHVhV2tZWitkNUtDVDNOL1ZvYW1rYjJabW9LT2I","https://player.cuevana2.io/irgotoolp.php?url=eTllbW9hZHpYNURLejlaalg2T3BsYy9PMHNTV29hYWVuY3JYMEpHVm9LRm9uWlRYbTVKL201K3dmcktRMEphbmFRPT0&sub=https://sub.cuevana2.io/vtt-sub/sub7/Daybreak.S01E02.vtt"]
reproductor: fembed
clasificacion: '+10'
tags:
- Comedia
---










